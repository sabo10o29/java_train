//
//  main.c
//  5章
//
//  Created by 村瀬慶和 on 2017/04/02.
//  Copyright (c) 2017年 村瀬慶和. All rights reserved.
//

#include <stdio.h>
void rei5_2();
void kadai5_1();
void kadai5_2();
void kadai5_3();
void kadai5_4();
void kadai5_5();

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    kadai5_1();
    kadai5_2();
    kadai5_3();
    kadai5_4();
    kadai5_5();
    return 0;
}


void rei5_2(){
    int i, x;
    int a[10] = {
        72, 7, 35, 18, 63, 20, 44, 80, 91, 52
    };
    int b[10] = {
        3, 5, 10, 8, 19, 11, 7, 1, 0, 5
    };
    
    for(i = 0; i < 10; i++){
        x = a[i] * b[i];
        printf("a[%d] * b[%d] = %d \n", i, i, x);
    }
    
}

void kadai5_1(){
    int a[10] = {
        72, 7, 35, 18, 63, 20, 44, 80, 91, 52
    };
    int i;
    for(i = 0; i<10; i++){
        if(a[i]>=50){
            printf("a[%d] = %d", i, a[i]);
        }
    }
    
}

void kadai5_2(){
    int a[10] = {
        72, 7, 35, 18, 63, 20, 44, 80, 91, 52
    };
    int i, total=0;
    for(i = 0; i<10; i++){
        total += a[i];
    }
    printf("sum of a[] = %d", total);
    
}

void kadai5_3(){
    int a[10] = {
        72, 7, 35, 18, 63, 20, 44, 80, 91, 52
    };
    int i, count = 0;
    
    for(i = 0; i<10; i++){
        if((a[i]%2)!=0) ++count;
    }
    printf("奇数の数は%d個です。", count);
}

void kadai5_4(){
    int a[10] = {
      56, -1, 63, 45, 80, -1, 78, 90, 48, 72
    };
    int i, max = 0, member = 0, pass = 0;
    for(i=0; i<10; i++){
        if(a[i] >= 0){
            ++member;
            if(a[i] >= 70){
                ++pass;
                if(max<a[i])max = a[i];
            }
            
        }
    }
    printf("member: %d\n",member);
    printf("pass: %d\n",pass);
    printf("best score: %d\n",max);
    printf("passing rate: %d％\n",(pass/member)*100);
    
}

void kadai5_5(){
    int a[10] = {
        56, -1, 63, 45, 80, -1, 78, 90, 48, 72
    };
    int i=0, j=0;
    int result[11] = {0,0,0,0,0,0,0,0,0,0,0};
    for(i=0; i<10; i++){
        int val = a[i]/10;
        ++result[val];
    }
    
    for(i=10; i>=0; i--){
        printf("%d:  ",i*10);
        for(j=1; j<=result[i]; j++){
            printf("*");
        }
        printf("\n");
    }
    
    
}






