//
//  main.c
//  8章
//
//  Created by 村瀬慶和 on 2017/04/13.
//  Copyright (c) 2017年 村瀬慶和. All rights reserved.
//

#include <stdio.h>
#define NUM 5

void kadai8_1();
void kadai8_2();
void kadai8_3();
void inc_value1(int val);
void kadai8_4();
void kadai8_5();
void inc_value3_1(int* a, int size);
void inc_value3_2(int a[], int size);
void kadai8_6();
void inc_value4(int* a, int ind, int size);
void kadai8_7();
int sum(int a[][3], int n);
void kadai8_8();
void kadai8_9();
void kadai8_10();
char* month_name(int m);
void kadai8_11(int argc, char* argv[]);

char str[] = "fundamental";

int main(int argc, const char * argv[]) {
    /*kadai8_1();
    kadai8_2();
    kadai8_3();
    kadai8_4();
    kadai8_5();
    kadai8_6();
    kadai8_7();
    kadai8_8();
    kadai8_9();
    kadai8_10();*/
    
    kadai8_11(argc, argv);
    return 0;
}

void kadai8_1(){
    
    int n = 100;
    int *ip1;
    int **ip2;
    
    ip1= &n;
    ip2 = &ip1;
    
    printf ("n      =   %d\n", n);
    printf ("&n     =   %x\n", n);
    printf ("*ip1   =   %d\n", n);
    printf ("ip1    =   %x\n", n);
    printf ("&ip1   =   %x\n", n);
    printf ("**ip   =   %d\n", n);
    printf ("*ip2   =   %x\n", n);
    
    return;
}

void kadai8_2(){
    
    int x = 10;
    
    printf("x = %d\n", x);
    
    printf("call inc_value\n");
    inc_value1 (x);
    
    printf("x = %d\n", x);
    
    return;
}

void inc_value1(int val){
    val++;
}

void kadai8_3(){
    int i=0;
    char* p = str;
    
    //配列名をそのまま使用する方法
    while(*(str+i) != '\0'){
        fprintf(stderr, "%c\n", *(str+i));
        i++;
    }
    
    
    
    //ポインタ変数を用いる方法
    while(*p != '\0'){
        fprintf(stderr, "%c\n", *p);
        p++;
    }
    
    return;
}

void kadai8_4(){
    
    int a[NUM] = { 10, 20, 30, 40, 50 };
    int* pa;
    int i;
    
    pa = &a[0];
    for(i = 0; i < NUM; i++){
        printf("*(pa+%d) = %d\t", i , *(pa + i));
        printf("*pa+%d = %d\n", i, *pa + i);
    }
    
    return;
}

void kadai8_5(){
    
    int a[NUM] = { 10, 20, 30, 40, 50 };
    int* pa;
    int i;
    
    pa = &a[0];
    for(i = 0; i < NUM; i++){
        printf("a[%d] = %d\n", i, a[i]);
    }
    inc_value3_1(a, NUM);
    
    printf("call inc_value3\n");
    for(i = 0; i < NUM; i++){
        printf("a[%d] = %d\n", i, a[i]);
    }
    
    inc_value3_2(a, NUM);
    
    printf("call inc_value4\n");
    for(i = 0; i < NUM; i++){
        printf("a[%d] = %d\n", i, a[i]);
    }
    
    return;
}

void inc_value3_1(int* a, int size){
    int i;
    for (i=0; i<size; i++) {
        (*a)++;
        a++;
    }
    return;
}

void inc_value3_2(int a[], int size){
    int i;
    for (i=0; i<size; i++) {
        a[i]++;
    }
    return;
}

void kadai8_6(){
    int a[NUM] = { 10, 20, 30, 40, 50 };
    int i, idx;
    char buff[BUFSIZ];
    
    printf("Input num : ");
    gets(buff);
    idx = atoi (buff) -1;
    
    if(idx < 0 || NUM <= idx){
        printf("ERROR\n");
        exit(1);
    }
    for (i=0; i<NUM; i++) {
        printf("a[%d] = %d\n", i, a[i]);
    }
    
    printf("call inc_value4\n");
    inc_value4(&(a[idx]), idx, NUM);
    
    for(i = 0; i < NUM; i++){
        printf("a[%d] = %d\n", i, a[i]);
    }
    
    return;
}


void inc_value4(int* a, int ind, int size){
    
    int i;
    for (i=0; i<(size-ind); i++) {
        (*a)++;
        a++;
    }
    
    return;
}

void kadai8_7(){
    int x[][3] ={
        {1, 2, 3},
        {4, 5, 6},
        {10, 11, 12}
    };
    int i;
    
    for (i=0; i<3; i++) {
        printf("row %d = %d\n", i, sum(x,i));
    }
}
int sum(int a[][3], int n){
    return a[n][0]+a[n][1]+a[n][2];
}

void kadi8_8(){
    
    char a[5] = {
        'a','b','c','d','e'
    };
    char *pa;
    int i;
    
    pa = a;
    
    for(i =0; i<5; i++){
        printf("a+%d = %x\t", i, a + i);
        printf("&a[%d] = %x\t", i, &a[i]);
        printf("pa+%d = %x\t", i, pa+i);
        printf("a[%d] = %c\n", i, a[i]);
        
    }
    
    return;
}

void kadi8_9(){
    
    int a[5] = {
        10,11,12,13,14
    };
    int *pa;
    int i;
    
    pa = a;
    
    for(i =0; i<5; i++){
        printf("a+%d = %x\t", i, a + i);
        printf("&a[%d] = %x\t", i, &a[i]);
        printf("pa+%d = %x\t", i, pa+i);
        printf("a[%d] = %d\n", i, a[i]);
        
    }
    
    return;
}

void kadai8_10(){
    int month;
    
    printf("Input month : ");
    scanf("%d", &month);
    printf("%d: %s\n", month, month_name(month));
}

char* month_name(int m){
    
    static char *name[] = {
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    };
    
    
   return name[m];
}

void kadai8_11(int argc, char* argv[]){
    
    int i=0, j=0;
    while( *++argv != NULL){
        printf("%d: %s -> ", i, *argv );
        char c = **argv;
        while(c != '\0'){
            printf("%c ", c);
            j++;
            c = *(*argv+j);
        }
        
        printf("\n");
        i++;
        j=0;
    }
    
}

void kadai8_12(){
    //right-left=要素数
    //>>1　2^1で割る　→　要素の半分の値
    //leftに足すことで中間地点のアドレスになる
    //中央値の値を取得
    
    //昇順にならべる：交差する＝中央値よりも右に小さい左に大きくなっていれば終了
    
    //dowhileの中のwhileの不等号
}


