//
//  main.c
//  6章
//
//  Created by 村瀬慶和 on 2017/04/02.
//  Copyright (c) 2017年 村瀬慶和. All rights reserved.
//

//
//  main.c
//  5章
//
//  Created by 村瀬慶和 on 2017/04/02.
//  Copyright (c) 2017年 村瀬慶和. All rights reserved.
//

#include <stdio.h>
#include <string.h>
void rei5_2();
void kadai5_1();
void kadai5_2();
void kadai5_3();
void kadai5_4();
void kadai5_5();
void kadai6_1();
void kadai6_2();
void kadai6_3();
void kadai6_4();
void kadai6_5();
void kadai6_6();

int main(int argc, const char * argv[]) {
    
    kadai6_1();
    kadai6_2();
    kadai6_3(2,"/Users/YoshikazuMurase/Desktop/6章/6章/test.txt");
    kadai6_4(2,"/Users/YoshikazuMurase/Desktop/6章/6章/test.txt");
    kadai6_5(2,"/Users/YoshikazuMurase/Desktop/6章/6章/test.txt");
    kadai6_6(2,"/Users/YoshikazuMurase/Desktop/6章/6章/6_6test.txt");
    return 0;
}

void kadai6_1(){
    printf("文字列を入力して下さい。\n");
    char str[128];
    scanf("%s",str);
    int i = strlen(str);
    printf("Input = <%s> (%d bytes)\n",str, i);
}


void kadai6_2(){
    printf("文字列を入力して下さい。\n");
    char str[128];
    scanf("%s",str);
    strcat(str, "XYZ");
    printf("%s\n",str);         //strcatを用いた文字列の連結
    int length = strlen(str);
    str[length] = 'A';
    str[length+1] = 'B';
    str[length+2] = 'C';
    printf("%s\n",str);         //配列に直接文字を書き込んでで連結
}

void kadai6_3(int argc, char *argv[]){
    
    char buffer[BUFSIZ];
    FILE *fp;
    
    if(argc != 2){
        exit(1);
    }
    
    //ファイルオープン
    fp = fopen (argv, "r");
    if(fp == NULL){
        exit(1);
    }
    printf("ファイルをロードしました。(kadai6_3)\n");
    
    //ファイルの終わりまで繰り返す
    while (fgets(buffer, BUFSIZ, fp) != NULL){
        //読み込んだ行を表示する
        printf("%s",buffer);
    }
    printf("\n");
    
    //ファイルのクローズ
    fclose(fp);
}

void kadai6_4(int argc, char *argv[]){
    char buffer[BUFSIZ];
    FILE *fp;
    
    if(argc != 2){
        exit(1);
    }
    
    //ファイルオープン
    fp = fopen (argv, "r");
    if(fp == NULL){
        exit(1);
    }
    printf("ファイルをロードしました。(kadai6_4)\n");
    
    //ファイルの終わりまで繰り返す
    int i;
    while (fgets(buffer, BUFSIZ, fp) != NULL){
        //読み込んだ行を表示する
        for (i=0; i<=strlen(buffer); i++) {
            if(buffer[i]>=97&&buffer[i]<=122){
                buffer[i] = buffer[i]-32;
            }
        }
        printf("%s",buffer);
    }
    printf("\n");
    
    //ファイルのクローズ
    fclose(fp);
}

void kadai6_5(int argc, char *argv[]){
    char buffer[BUFSIZ];
    FILE *fp;
    
    if(argc != 2){
        exit(1);
    }
    
    //ファイルオープン
    fp = fopen (argv, "r");
    if(fp == NULL){
        exit(1);
    }
    printf("ファイルをロードしました。(kadai6_5)\n");
    
    //ファイルの終わりまで繰り返す
    int i,j=0;
    while (fgets(buffer, BUFSIZ, fp) != NULL){
        char rev[strlen(buffer)+1];
        
        //読み込んだ行を表示する
        for (i=strlen(buffer)-1; i>=0; i--) {
            if(buffer[i]>=97&&buffer[i]<=122){
                buffer[i] = buffer[i]-32;
            }
            rev[j]=buffer[i];
            j++;
        }
        rev[j]='\0';
        printf("%s",rev);
    }
    printf("\n");
    
    //ファイルのクローズ
    fclose(fp);
}

void kadai6_6(int argc, char *argv[]){
    char buffer[BUFSIZ];
    FILE *fp;
    
    if(argc != 2){
        exit(1);
    }
    
    //ファイルオープン
    fp = fopen (argv, "w");
    if(fp == NULL){
        exit(1);
    }
    printf("ファイルをロードしました。(kadai6_6)\n");
    
    //ファイルの終わりまで繰り返す
    char str[128];
    printf("文字を入力して下さい。\n");
    scanf("%s",str);
    while(str[0] != 'Q'){
        fprintf(fp, str);
        printf("文字を入力して下さい。\n");
        scanf("%s",str);
    }
    fclose(fp);
}

